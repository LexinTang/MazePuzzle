package mazeworld;

import javax.swing.*;

import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

import javax.swing.Timer;

import mazeworld.UUSearchProblem.UUSearchNode;

public class MazeDriver extends JApplet {

	private static final long serialVersionUID = 1L;
	private static final int CANVAS_SIZE = 800;
	private static final int SQUARE_SIZE = 20;
	

	public static int m;
	
	private static MazeConf myMaze;
	
	private Timer timer;
	private static final int DELAY = 500;
	public static ArrayList<UUSearchProblem.UUSearchNode> path;
	
	public void init() {

		/*#########################################################################*/
		/* Change m for testing                                                    */
		/* m = 1: simlple BFS search (40x40)                                       */
		/* m = 2: A* search (40x40)                                                */
		/* m = 3: Multi robot planning (7x7) (provided maze with 3 robots)         */
		/* m = 4: Multi robot planning (7x7) (a corridor with 2 robots)            */
		/* m = 5: Multi robot planning (10x10) (a maze with no walls, 3 robots)    */
		/* m = 6: Multi robot planning (10x10) (a narrow passage with 3 robots)    */
		/* m = 7: Multi robot planning (40x40) (a large maze with 2 robots)        */
		/* m = 8: Blind search (40x40)                                             */
		/*#########################################################################*/
		
		m = 8;
			
			
			// simple BFS search
		if (m == 1) {
			myMaze = new MazeConf("test/maze40.txt");
			path = myMaze.simpleSearch(0, 0, myMaze.mazeLength-1, myMaze.mazeHeight - 1);
			setSize(CANVAS_SIZE, CANVAS_SIZE);
		}
		
		else if (m == 2) {
			myMaze = new MazeConf("test/maze40.txt");
			path = myMaze.aStarSearch(0, 0, myMaze.mazeLength-1, myMaze.mazeHeight - 1);
			setSize(CANVAS_SIZE, CANVAS_SIZE);
		}
		else if (m == 3) {
			myMaze = new MazeConf("test/maze.txt");
			
			int [][]start = new int[3][2];
			
			start[0][0] = 6;
			start[0][1] = 0;
			start[1][0] = 0;
			start[1][1] = 0;
			start[2][0] = 3;
			start[2][1] = 0;
			
			int [][]goal = new int[3][2];
			
			goal[0][0] = 6;
			goal[0][1] = 6;
			goal[1][0] = 5;
			goal[1][1] = 6;
			goal[2][0] = 4;
			goal[2][1] = 6;
			
			path = myMaze.multiSearch(start, goal);
			setSize(7*SQUARE_SIZE, 7*SQUARE_SIZE);
		}
		else if (m == 4)  {
			myMaze = new MazeConf("test/maze2.txt");
		
			int [][]start = new int[2][2];
			
			start[0][0] = 6;
			start[0][1] = 2;
			start[1][0] = 6;
			start[1][1] = 1;
			

			
			int [][]goal = new int[2][2];
			
			goal[0][0] = 6;
			goal[0][1] = 0;
			goal[1][0] = 6;
			goal[1][1] = 6;
			

			
			
			path = myMaze.multiSearch(start, goal);
			setSize(7*SQUARE_SIZE, 7*SQUARE_SIZE);
		}
		
		else if (m == 5) {
			myMaze = new MazeConf("test/maze10e.txt");
			
			int [][]start = new int[3][2];
			
			start[0][0] = 9;
			start[0][1] = 0;
			start[1][0] = 0;
			start[1][1] = 0;
			start[2][0] = 5;
			start[2][1] = 0;
			
			int [][]goal = new int[3][2];
			
			goal[0][0] = 9;
			goal[0][1] = 9;
			goal[1][0] = 8;
			goal[1][1] = 9;
			goal[2][0] = 7;
			goal[2][1] = 9;
			
			path = myMaze.multiSearch(start, goal);
			setSize(10*SQUARE_SIZE, 10*SQUARE_SIZE);
		}
		else if (m == 6) {
			myMaze = new MazeConf("test/maze10.txt");
			
			int [][]start = new int[3][2];
			
			start[0][0] = 9;
			start[0][1] = 0;
			start[1][0] = 0;
			start[1][1] = 0;
			start[2][0] = 5;
			start[2][1] = 0;
			
			int [][]goal = new int[3][2];
			
			goal[0][0] = 9;
			goal[0][1] = 9;
			goal[1][0] = 8;
			goal[1][1] = 9;
			goal[2][0] = 7;
			goal[2][1] = 9;
			
			path = myMaze.multiSearch(start, goal);
			setSize(10*SQUARE_SIZE, 10*SQUARE_SIZE);
		}
		else if (m == 7) {
			myMaze = new MazeConf("test/maze40.txt");
			
			int [][]start = new int[2][2];
			
			start[0][0] = 0;
			start[0][1] = 0;
			start[1][0] = 39;
			start[1][1] = 0;

			
			int [][]goal = new int[2][2];
			
			goal[0][0] = 39;
			goal[0][1] = 39;
			goal[1][0] = 0;
			goal[1][1] = 39;

			
			path = myMaze.multiSearch(start, goal);
			setSize(CANVAS_SIZE, CANVAS_SIZE);
		}
		
		
		else if (m == 8) {
			myMaze = new MazeConf("test/maze40.txt");
			path = myMaze.blindSearch(myMaze.mazeLength-1, myMaze.mazeHeight - 1);
			setSize(CANVAS_SIZE, CANVAS_SIZE);
		}
		else {
			System.out.println("Please provide valid m (1 to 8)");
			System.exit(0);
		}
		
		
		
		Container cp = getContentPane();
		cp.add(new Canvas());
		LocalListener listener = new LocalListener();
		timer = new Timer(DELAY, listener);
		timer.start();
		setVisible(true);
		
	}
	
	// To let robot move step by step.
	public class LocalListener implements ActionListener {
		public void actionPerformed (ActionEvent event) {
			
			if (path.size() > 1) {
				path.remove(0);
			}
			repaint();
		}
		
		// Not implemented methods.
		public void mouseClicked(MouseEvent event) {}
		public void mousePressed(MouseEvent event) {}
		public void mouseReleased(MouseEvent event) {}
		public void mouseEntered(MouseEvent event) {}
		public void mouseExited(MouseEvent event) {}
	}
	private class Canvas extends JPanel {

		private static final long serialVersionUID = 1L;

		public void paintComponent(Graphics page) {
			super.paintComponent(page);
			drawMaze(page);
		}
		
		public void drawMaze(Graphics page) {
			Color squareColor, circleColor;
			
			int x, y;
			
			for (int i = 0; i < myMaze.mazeHeight; i++) {
				for (int j = 0; j < myMaze.mazeLength; j++) {
					if (myMaze.maze[i][j] == 0)
						squareColor = Color.white;
					else
						squareColor = Color.black;
					drawSquare(page, i, j, squareColor);
				}
			}
			
			// support 6 robots.
			Color []robotColor = new Color[6];
			robotColor[0] = Color.red;
			robotColor[1] = Color.yellow;
			robotColor[2] = Color.green;
			robotColor[3] = Color.cyan;
			robotColor[4] = Color.orange;
			robotColor[5] = Color.blue;
			
			UUSearchNode goal = path.get(path.size() - 1);
			UUSearchNode current = path.get(0);
			
			if (m == 1) {
				squareColor = Color.red;
				drawSquare(page, ((SimpleSearch.MazeNode)goal).state[0], ((SimpleSearch.MazeNode)goal).state[1], squareColor);
				
				circleColor = Color.red;
				
				x = ((SimpleSearch.MazeNode)current).state[0];
				y = ((SimpleSearch.MazeNode)current).state[1];
				drawCircle(page, x, y, circleColor);
			}
			
			else if (m == 2) {
				squareColor = Color.red;
				drawSquare(page, ((SimpleSearch.MazeNode)goal).state[0], ((SimpleSearch.MazeNode)goal).state[1], squareColor);
				
				circleColor = Color.red;
				
				x = ((SingleASearch.AStarNode)current).state[0];
				y = ((SingleASearch.AStarNode)current).state[1];
				drawCircle(page, x, y, circleColor);
			}
			else if (m == 3 || m == 4 || m == 5 || m == 6 || m == 7) {
				int[][] currentState = ((MultiSearch.MultiNode)current).state;
				int[][] goalState = ((MultiSearch.MultiNode)goal).state;
				int robotNumber = currentState.length;
				for (int i = 0; i < robotNumber && i < 6; i++) {
					
					squareColor = robotColor[i];
					drawSquare(page, goalState[i][0], goalState[i][1], squareColor);
					
					circleColor = robotColor[i];
					
					x = currentState[i][0];
					y = currentState[i][1];
					drawCircle(page, x, y, circleColor);
				}
				
				
			}
			else if (m == 8) {
				ArrayList<int []> currentState = ((BlindSearch.BlindNode)current).state;
				ArrayList<int []> goalState = ((BlindSearch.BlindNode)goal).state;
				
				for (int [] aState : goalState) {
					
					squareColor = Color.green;
					drawSquare(page, aState[0], aState[1], squareColor);
				}
				for (int []bState : currentState) {
					if (path.size() == 1)
						circleColor = Color.green;
					else
						circleColor = Color.gray;
					
					x = bState[0];
					y = bState[1];
					drawCircle(page, x, y, circleColor);
				}
			}
			else {
				System.out.println("Please provide valid m (1 to 8)##");
			}
		
		}
		
		public void drawSquare(Graphics page, int row, int column, Color color) {
			page.setColor(color);
			page.fillRect(column * SQUARE_SIZE, row * SQUARE_SIZE, SQUARE_SIZE,
			         SQUARE_SIZE);
			page.setColor(Color.black);
			page.drawRect(column * SQUARE_SIZE, row * SQUARE_SIZE, SQUARE_SIZE,
			         SQUARE_SIZE);
		}
		
		public void drawCircle(Graphics page, int row, int column, Color color) {
			page.setColor(color);
			page.fillOval(column * SQUARE_SIZE, row * SQUARE_SIZE,
					 SQUARE_SIZE, SQUARE_SIZE);
			page.setColor(Color.black);
			page.drawOval(column * SQUARE_SIZE, row * SQUARE_SIZE, SQUARE_SIZE,
			         SQUARE_SIZE);
		}
	}
}
