package mazeworld;
import java.util.ArrayList;
import java.util.Iterator;


public class BlindSearch extends UUSearchProblem {
	
	private int mazeLength, mazeHeight;
	private int goalX, goalY;
	
	private int [][] maze;
	
	public BlindSearch(int [][] mazeInput, int length, int height, 
			 int gX, int gY) {
		this.maze = mazeInput;
		this.mazeLength = length; 
		this.mazeHeight = height;
		this.goalX = gX;
		this.goalY = gY;
		ArrayList<int []> state = new ArrayList<>();
		for (int i = 0; i < mazeHeight; i++) {
			for (int j = 0; j < mazeLength; j++) {
				if (maze[i][j] == 0) {
					int []aState = new int[2];
					aState[0] = i;
					aState[1] = j;
					state.add(aState);
				}
			}
		}
		
		startNode = new BlindNode(state, 0);
	}
	
	public class BlindNode implements UUSearchNode {
		private int depth, priority;
		public ArrayList<int []> state;
		
		public BlindNode(ArrayList<int []> stateInput, int d) {
			state = stateInput;
			
			depth = d;
			priority = depth + heuristic(state);
		}
		
		private boolean isSafeState(int x, int y) {
			if (x >= 0 && x < mazeHeight 
					&& y >= 0 && y < mazeLength
					&& maze[x][y] != 1) {
				return true;
			}
			else {
				return false;
			}
		}
		
		private ArrayList<int []> transition(int dir) {
			
			ArrayList<int []>newStateSet = new ArrayList<>();
			Iterator<int []> iter = this.state.iterator();
			
			while (iter.hasNext()) {
				int [] aState = iter.next();
				int [] newState = new int[2];
				if (dir == 1) { // move left
					newState[0] = aState[0] - 1;
					newState[1] = aState[1];
				}
				else if (dir == 2) { // move right
					newState[0] = aState[0] + 1;
					newState[1] = aState[1];
				}
				else if (dir == 3) { // move up
					newState[0] = aState[0];
					newState[1] = aState[1] - 1;
				}
				else if (dir == 4) { // move down
					newState[0] = aState[0];
					newState[1] = aState[1] + 1;
				}
				
				
				if (isSafeState(newState[0], newState[1])) {
					newStateSet.add(newState);
				}
				else { // if a move is illegal, the robot stay where it was.
					int flag = 0;
					Iterator<int[]>iter2 = newStateSet.iterator();
					while(iter2.hasNext()) {
						int [] temp = iter2.next();
						if (temp[0] == aState[0] && temp[1] == aState[1]) {
							flag = 1;
							break;
						}
							
					}
					if (flag == 0)
						newStateSet.add(aState);
				}
			}
			
			return newStateSet;
			
		}
		
		public ArrayList<UUSearchNode> getSuccessors() {
			ArrayList<UUSearchNode> list = new ArrayList<>();
			
			// Move left
			ArrayList<int []>newStateSetLeft = transition(1);
			if (newStateSetLeft.size() > 0) {
				UUSearchNode newNode = new BlindNode(newStateSetLeft, this.depth + 1);
				list.add(newNode);
			}
			
			// Move left
			ArrayList<int []>newStateSetRight = transition(2);
			if (newStateSetRight.size() > 0) {
				UUSearchNode newNode = new BlindNode(newStateSetRight, this.depth + 1);
				list.add(newNode);
			}
			
			// Move left
			ArrayList<int []>newStateSetUp = transition(3);
			if (newStateSetUp.size() > 0) {
				UUSearchNode newNode = new BlindNode(newStateSetUp, this.depth + 1);
				list.add(newNode);
			}
			
			// Move left
			ArrayList<int []>newStateSetDown = transition(4);
			if (newStateSetDown.size() > 0) {
				UUSearchNode newNode = new BlindNode(newStateSetDown, this.depth + 1);
				list.add(newNode);
			}

			return list;
		}
		
		
		@Override
		public boolean goalTest() {
			ArrayList<int[]>goalState = new ArrayList<>();
			int []goal = new int[2];
			goal[0] = goalX;
			goal[1] = goalY;
			goalState.add(goal);
			UUSearchNode goalNode = new BlindNode(goalState, 0);
			return equals(goalNode);
		}

		// an equality test is required so that visited lists in searches
		// can check for containment of states
		@Override
		public boolean equals(Object other) {
			if (state.size() != (((BlindNode) other).state).size())
				return false;
			for (int [] aState : ((BlindNode) other).state) {
				if (! hasIt(aState[0], aState[1]))
					return false;
			}
			return true;
		}

		@Override
		public int hashCode() {
			int hash = 0;
			int k = 0;
			for (int i = 0; i < mazeHeight; i++){
				for (int j = 0; j < mazeLength; j++) {
					
					if(this.hasIt(i, j)) {
						hash = hash + i*(int)Math.pow(10, k+1) + j*(int)Math.pow(10, k);
						k = k + 2;
					}
						
				}
			}
			
			return hash;
		}


		
		@Override
		public String toString() {
			
			String string = "";
			for (int i = 0; i < mazeHeight; i++){
				for (int j = 0; j < mazeLength; j++) {
					int []curPosition = new int[2];
					curPosition[0] = i;
					curPosition[1] = j;
					if(this.hasIt(i, j)) {
						string = string + "(" + curPosition[0] + "," + curPosition[1] + "," + depth + ")";
					}
						
				}
			}
			return string +"\n";
		}

		private boolean hasIt(int x, int y) {
			Iterator<int []>iter = this.state.iterator();
			while(iter.hasNext()) {
				int [] aState = iter.next();
				if (aState[0] == x && aState[1] == y)
					return true;
			}
			return false;
		}
		/*
        You might need this method when you start writing 
        (and debugging) UUSearchProblem.
        */
		@Override
		public int getDepth() {
			return depth;
		}
		
		
		public int getValue() {
			return priority;
		}
		
 		
	}
	public int heuristic(ArrayList<int []> state) {
		int maxManhattan = 0;
		int []aState;
		Iterator<int []>iter =state.iterator();
		if (iter.hasNext()) {
			aState = iter.next();
			maxManhattan = Math.abs(aState[0] - goalX) + Math.abs(aState[1] - goalY);
		}
		while (iter.hasNext()) {
			aState = iter.next();
			maxManhattan = (maxManhattan +
					Math.abs(aState[0] - goalX) + Math.abs(aState[1] - goalY));
//			maxManhattan = Math.max(maxManhattan, 
//					Math.abs(aState[0] - goalX) + Math.abs(aState[1] - goalY));
		}
		
		return maxManhattan;
	}
}