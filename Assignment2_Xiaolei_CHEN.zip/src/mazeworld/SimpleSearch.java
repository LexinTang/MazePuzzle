package mazeworld;
import java.util.ArrayList;
import java.util.Arrays;


public class SimpleSearch extends UUSearchProblem {
	
	private int mazeLength, mazeHeight;
	protected int startX, startY, goalX, goalY;
	private int [][] maze;
	
	public SimpleSearch(int [][] array, int length, int height, 
			int sX, int sY, int gX, int gY) {
		this.maze = array;
		this.mazeLength = length; 
		this.mazeHeight = height;
		this.startX = sX;
		this.startY = sY;
		this.goalX = gX;
		this.goalY = gY;
		startNode = new MazeNode(startX, startY, 0);
	}
	
	public class MazeNode implements UUSearchNode {
		protected int depth;
		protected int []state;
		public MazeNode(int x, int y, int d) {
			state = new int[2];
			this.state[0] = x;
			this.state[1] = y;
			depth = d;
		}
		
		private boolean isSafeState(int x, int y) {
			if (x >= 0 && x < mazeLength 
					&& y >= 0 && y < mazeHeight
					&& maze[x][y] != 1) {
				return true;
			}
			else {
				return false;
			}
		}
		
		
		public ArrayList<UUSearchNode> getSuccessors() {
			ArrayList<UUSearchNode> list = new ArrayList<>();
			
			// Move left
			if (isSafeState(this.state[0] - 1, this.state[1])) {
				list.add(createUUSearchNode(this.state[0] - 1, this.state[1], this.depth + 1));
			}
			// Move right
			if (isSafeState(this.state[0] + 1, this.state[1])) {
				list.add(createUUSearchNode(this.state[0] + 1, this.state[1], this.depth + 1));
			}
			// Move up
			if (isSafeState(this.state[0], this.state[1] - 1)) {
				list.add(createUUSearchNode(this.state[0], this.state[1] - 1, this.depth + 1));
			}
			// Move down
			if (isSafeState(this.state[0], this.state[1] + 1)) {
				list.add(createUUSearchNode(this.state[0], this.state[1] + 1, this.depth + 1));
			}
			
			return list;
		}
		
		public UUSearchNode createUUSearchNode (int x, int y, int depth) {
			return new MazeNode(x, y, depth);
			
		}
		
		@Override
		public boolean goalTest() {
			return equals(new MazeNode(goalX, goalY, 0));
		}

		// an equality test is required so that visited lists in searches
		// can check for containment of states
		@Override
		public boolean equals(Object other) {
			return Arrays.equals(state, ((MazeNode) other).state);
		}

		@Override
		public int hashCode() {
			return state[0] * 10 + state[1];
		}

		@Override
		public String toString() {
			
			return "(" + state[0] + "," + state[1] + "," + depth + ")";
		}

		/*
        You might need this method when you start writing 
        (and debugging) UUSearchProblem.
        */
		@Override
		public int getDepth() {
			return depth;
		}
		
		// no use here.
		public int getValue() {
			return 0;
		}
	}
}