package mazeworld;

import java.util.Arrays;


public class SingleASearch extends SimpleSearch {
	
	public SingleASearch(int [][] array, int length, int height, 
			int sX, int sY, int gX, int gY) {
		super(array, length, height, sX, sY, gX, gY);
		startNode = new AStarNode(sX, sY, 0, heuristic(sX, sY, gX, gY));
	}
	
	public class AStarNode extends MazeNode {
		private int priority;
		public AStarNode (int x, int y, int d, int p) {
			super(x, y, d);
			this.priority = p;
		}
		
		@Override
		public UUSearchNode createUUSearchNode (int x, int y, int depth) {
			int p = depth + heuristic(x, y, goalX, goalY);
			return new AStarNode(x, y, depth, p);
		}
		
		@Override
		public boolean goalTest() {
			return equals(new AStarNode(goalX, goalY, 0, 0));
		}

		// an equality test is required so that visited lists in searches
		// can check for containment of states
		@Override
		public boolean equals(Object other) {
			return Arrays.equals(state, ((AStarNode) other).state);
		}
		
		
		@Override
		public String toString() {
			
			return "(" + state[0] + "," + state[1] + "," + depth + "," + priority + ")";
		}
		
		@Override
		public int getValue() {
			return priority;
		}

	}
	
	// Heuristic is the Manhattan distance
	private int heuristic(int x, int y, int gX, int gY) {
		return Math.abs(x - gX) + Math.abs(y - gY);
		
	}
	
}