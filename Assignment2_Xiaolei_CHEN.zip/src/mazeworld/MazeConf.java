package mazeworld;

import java.io.*;
import java.util.Comparator;
import java.util.ArrayList;

public class MazeConf {
	// The size of maze is totally controlled by input file.
	public int mazeLength;
	public int mazeHeight;
	public int [][] maze;
	
	Comparator<UUSearchProblem.UUSearchNode> comparator;
	
	
	// Constructor
	public MazeConf(String fileName) {
		try {
			maze = readFile(fileName);
			if (maze == null) {
				System.out.println("Error in maze file.");
				System.exit(0);
			}

			mazeHeight = maze.length;
			mazeLength = maze[0].length;
			comparator = new PriorityComparator();
			
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public ArrayList<UUSearchProblem.UUSearchNode> simpleSearch(int startX, int startY, int goalX, int goalY) {
		SimpleSearch mazeProblem = new SimpleSearch(maze, mazeLength, mazeHeight, 
				startX, startY, goalX, goalY);
		
		ArrayList<UUSearchProblem.UUSearchNode> path;
		path = mazeProblem.breadthFirstSearch();	
		System.out.println("bfs path length:  " + path.size() + " " + path);
		mazeProblem.printStats();
		System.out.println("--------");
		return path;
	}
	
	public ArrayList<UUSearchProblem.UUSearchNode> aStarSearch(int startX, int startY, int goalX, int goalY) {
		SingleASearch mazeProblem2 = new SingleASearch(maze, mazeLength, mazeHeight, 
				startX, startY, goalX, goalY);
		ArrayList<UUSearchProblem.UUSearchNode> path;
		path = mazeProblem2.aStarSearch(comparator);	
		System.out.println("A* path length:  " + path.size() + " " + path);
		mazeProblem2.printStats();
		System.out.println("--------");
		return path;
	}
	
	
	public ArrayList<UUSearchProblem.UUSearchNode> multiSearch(int [][]start, int [][]goal) {
		
		MultiSearch mazeProblem3 = new MultiSearch(maze, mazeLength, mazeHeight, start, goal);
		ArrayList<UUSearchProblem.UUSearchNode> path;
		path = mazeProblem3.aStarSearch(comparator);	
		
		System.out.println("Multi-robot path length:  " + path.size() + " " + path);
		mazeProblem3.printStats();
		System.out.println("--------");
		return path;
	}
	
	public ArrayList<UUSearchProblem.UUSearchNode> blindSearch(int goalX, int goalY) {
		BlindSearch mazeProblem4 = new BlindSearch(maze, mazeLength, mazeHeight, goalX, goalY);
		ArrayList<UUSearchProblem.UUSearchNode> path;
		path = mazeProblem4.aStarSearch(comparator);	
		System.out.println("blind robot path length:  " + path.size() + " "/* + path*/);
		mazeProblem4.printStats();
		System.out.println("--------");
		return path;
	}
	

	// Read maze from file. Adapted from:
	// http://www.avajava.com/tutorials/lessons/how-do-i-read-a-string-from-a-file-line-by-line.html
	private int[][] readFile(String filename) throws IOException{
		FileReader fileReader;
		File file = new File(filename);
		fileReader = new FileReader(file);
		BufferedReader bufferedReader = new BufferedReader(fileReader);
		StringBuffer stringBuffer = new StringBuffer();
		String line, string;
		int lineLength = 0;
		int lineTotal = 0;
		
		
		// Read the whole in a buffer.
		while ((line = bufferedReader.readLine()) != null) {
			if (lineLength == 0)
				lineLength = line.length();
				
			if (lineLength != line.length()) {
				bufferedReader.close();
				fileReader.close();
				return null;
			}
			stringBuffer.append(line);
			stringBuffer.append("\n");
			lineTotal++;
		}
		fileReader.close();
		string = stringBuffer.toString();
		// System.out.println(string);
		
		// Convert the maze into a 2D int array.
		int [][] array = new int[lineTotal][lineLength];
		int charCount = 0;
		for (int i = 0; i < lineTotal; i++) {
			for (int j = 0; j < lineLength; j++) {
				if(string.charAt(charCount) == '.')
					array[i][j] = 0;
				else
					array[i][j] = 1;
				charCount++;
			}
			charCount++;
		}
		
		// set maze size.
		mazeLength = lineLength;
		mazeHeight = lineTotal;
		return array;
	}
}
