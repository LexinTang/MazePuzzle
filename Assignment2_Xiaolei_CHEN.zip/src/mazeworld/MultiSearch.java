package mazeworld;

import java.util.ArrayList;
import java.util.Arrays;


public class MultiSearch extends UUSearchProblem{
	
	private int [][]maze;
	private int [][]start;
	private int [][]goal; 
	private int mazeLength, mazeHeight;
	private int robotNumber;
	
	// Constructor.
	public MultiSearch (int [][]mazeInput, int length, int height,
			int [][]startInput, int [][]goalInput) {
		maze = mazeInput;
		start = startInput;
		goal = goalInput;
		mazeLength = length;
		mazeHeight = height;
		robotNumber = start.length;
		
		startNode = new MultiNode (start, 0, heuristic(start, goal));
	}
	
	
	public class MultiNode implements UUSearchNode {
		public int [][] state;
		private int depth;
		private int priority;
		
		// Constructor
		public MultiNode (int [][] start, int d, int p) {
			state = stateCopy(start); // copy over the state.
			depth = d;
			priority = p;
		}
		
		// if move robot at position "position" to (x, y), collision?
		private boolean collision(int position, int x, int y) {
			for (int i = 0; i < robotNumber; i++) {
				if (i != position && state[i][0] == x && state[i][1] == y)
					return true;
				
			}
			return false;
		}
		
		private boolean isSafeState(int i, int x, int y) {
			if (x >= 0 && x < mazeHeight
					&& y >= 0 && y < mazeLength
					&& maze[x][y] != 1
					&& ! collision(i, x, y)) {
				return true;
			}
			else {
				return false;
			}
		}
		
		
		public ArrayList<UUSearchNode> getSuccessors() {
			ArrayList<UUSearchNode> list = new ArrayList<>();
			for (int i = 0; i < robotNumber; i++) {
				// Move left
				if (isSafeState(i, this.state[i][0] - 1, this.state[i][1])) {
					list.add(createUUSearchNode(i, this.state[i][0] - 1, this.state[i][1], this.depth + 1));
				}
				// Move right
				if (isSafeState(i, this.state[i][0] + 1, this.state[i][1])) {
					list.add(createUUSearchNode(i, this.state[i][0] + 1, this.state[i][1], this.depth + 1));
				}
				// Move up
				if (isSafeState(i, this.state[i][0], this.state[i][1] - 1)) {
					list.add(createUUSearchNode(i, this.state[i][0], this.state[i][1] - 1, this.depth + 1));
				}
				// Move down
				if (isSafeState(i, this.state[i][0], this.state[i][1] + 1)) {
					list.add(createUUSearchNode(i, this.state[i][0], this.state[i][1] + 1, this.depth + 1));
				}
				// Don't move
				if (isSafeState(i, this.state[i][0], this.state[i][1])) {
					list.add(createUUSearchNode(i, this.state[i][0], this.state[i][1], this.depth + 1));
				}
			}
			
			return list;
		}
		
		public UUSearchNode createUUSearchNode (int position, int x, int y, int depth) {
			int [][]newState = stateCopy(this.state);
			newState[position][0] = x;
			newState[position][1] = y;
			int p = depth + heuristic(newState, goal);
			return new MultiNode(newState, depth, p);
			
		}
		
		@Override
		public boolean goalTest() {
			return equals(new MultiNode(goal, 0, 0));
		}

		// an equality test is required so that visited lists in searches
		// can check for containment of states
		@Override
		public boolean equals(Object other) {
			for (int i = 0; i < robotNumber; i++) {
				if (! Arrays.equals(state[i], ((MultiNode) other).state[i]))
					return false;
			}
			return true;
		}

		@Override
		public int hashCode() {
			int hash = 0;
			for (int i = 0; i < robotNumber*2; i=i+2) {
				hash = hash + state[i/2][0]*(int)Math.pow(10, i+1) + state[i/2][1]*(int)Math.pow(10, i);
			}
			return hash;
		}

		@Override
		public String toString() {
			String string = "--------\n";
			for (int i = 0; i < robotNumber; i++) {
				string = string + "Robot " + i + ": " + state[i][0] + ", " + state[i/2][1] + "\n";
				
			}
			return string;
		}
		
		
		public int getDepth() {
			return depth;
		}
		
		public int getValue() {
			return priority;
		}
	}
	
	
	// Heuristic is sum of all the Manhattan distances
	private int heuristic(int [][]current, int [][]goal) {
		int sum = 0;
		for (int i = 0; i < robotNumber; i++)
			sum = sum + Math.abs(current[i][0] - goal[i][0]) + 
			Math.abs(current[i][0] - goal[i][0]);
//			sum = Math.max(sum,  Math.abs(current[i][0] - goal[i][0]) + 
//				Math.abs(current[i][0] - goal[i][0]));
		return sum;
	}
	
	private int [][] stateCopy(int [][] source) {
		int [][] dest = new int[robotNumber][2];
		for (int i = 0; i < robotNumber; i++) 
			for (int j = 0; j < 2; j++)
				dest[i][j] = source[i][j];
		return dest;
	}
	
	
	
}