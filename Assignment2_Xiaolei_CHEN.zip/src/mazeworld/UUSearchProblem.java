/**
 * General graph search algorithm, including BFS, memorizing DFS,
 * path checking DFS and iteratively deepening DFS
 * 
 * @author Xiaolei Chen, adapted from code provided by Devin Balkcom
 */

package mazeworld;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Queue;

public abstract class UUSearchProblem {
	
	// used to store performance information about search runs.
	//  these should be updated during the process of searches

	// see methods later in this class to update these values
	protected int nodesExplored;
	protected int maxMemory;

	protected UUSearchNode startNode;
	
	public interface UUSearchNode {
		public ArrayList<UUSearchNode> getSuccessors();
		public boolean goalTest();
		public int getDepth();
		public int getValue();

	}

	// breadthFirstSearch:  return a list of connecting Nodes, or null
	// no parameters, since start and goal descriptions are problem-dependent.
	//  therefore, constructor of specific problems should set up start
	//  and goal conditions, etc.
	
	public ArrayList<UUSearchNode> breadthFirstSearch() {
		resetStats();
		
		
		if (startNode == null) // no startNode
			return null;
		
		Queue<UUSearchNode> frontiers = new LinkedList<>();
		
		frontiers.add(startNode);
		
		HashMap<UUSearchNode, UUSearchNode> visited = new HashMap<>();
		
		visited.put(startNode, null);
		
		this.incrementNodeCount();
		this.updateMemory(visited.size());
		
		while(frontiers.peek() != null) {
			UUSearchNode currNode = frontiers.remove();
			if (currNode.goalTest()) {  // Goal node found
				return reverse(backchain(currNode, visited));				
			}
			
			// Otherwise, continue search the neighbors of currNode.
			ArrayList<UUSearchNode> neighbors = currNode.getSuccessors();
			Iterator<UUSearchNode> iter = neighbors.iterator();
			
			// Put all neighbors and there parent to visited node pool.
			while (iter.hasNext()) {
				UUSearchNode neighbor = iter.next(); // get next neighbor
				if (!visited.containsKey(neighbor)) { 
					// only if the neighbor has not been visited.
					frontiers.add(neighbor); 
					visited.put(neighbor, currNode); 
					
					this.incrementNodeCount();
					this.updateMemory(visited.size());
				}
			}
		}
		System.out.println("Goal Not Found!");
		return null;  // Goal node was not found. 
		
	}
	
	
	public ArrayList<UUSearchNode> aStarSearch(Comparator<UUSearchNode> comparator) {
		resetStats();
		
		
		if (startNode == null) // no startNode
			return null;
		
		PriorityQueue<UUSearchNode> frontier = new PriorityQueue<UUSearchNode>(11, comparator);
		HashMap<UUSearchNode, UUSearchNode> visited = new HashMap<>();
		
		// A copy of everything that is active in priority queue, with priority as value.
		HashMap<UUSearchNode, UUSearchNode>queueMap = new HashMap<>();
		
		frontier.add(startNode);
		queueMap.put(startNode, startNode);
		
		
		visited.put(startNode, null);
		this.incrementNodeCount();
		this.updateMemory(visited.size());
		
		while (frontier.peek() != null) {
			
			
			UUSearchNode currentNode = frontier.poll();
			
			if (currentNode.goalTest()) { // Goal found
				return reverse(backchain(currentNode, visited));
			}
			if (!queueMap.containsKey(currentNode)) { // It was marked as removed
				continue;
			}
			
			queueMap.remove(currentNode);
			
			
			List<UUSearchNode> neighbors = currentNode.getSuccessors();
			Iterator<UUSearchNode> iter = neighbors.iterator();
			while(iter.hasNext()) {
				UUSearchNode neighbor = iter.next();
				// add to priority queue if the node has not been visited.
				if (!visited.containsKey(neighbor)) {
					frontier.add(neighbor);
					visited.put(neighbor, currentNode); 
					queueMap.put(neighbor, neighbor);
					this.incrementNodeCount();
					this.updateMemory(visited.size());
				}
				// even if it has been visited, check its cost.
				else {
					if (queueMap.containsKey(neighbor)) {
						if (comparator.compare(neighbor, queueMap.get(neighbor)) > 0){
							// Mark the old node as removed by removing from queueMap
							// Add new one to the priority queue and queueMap.
							queueMap.remove(neighbor);
							queueMap.put(neighbor, neighbor);
							frontier.add(neighbor);
						}
					}
				}
			}
		}
		
		return null;
	}
	
	// backchain should only be used by bfs, not the recursive dfs
	private ArrayList<UUSearchNode> backchain(UUSearchNode node,
			HashMap<UUSearchNode, UUSearchNode> visited) {
		
		ArrayList<UUSearchNode> chain = new ArrayList<UUSearchNode>();
		while (node != null) {
			chain.add(node);
			node = visited.get(node);
		}
		
		return chain;
		
	}
		
	protected void resetStats() {
		nodesExplored = 0;
		maxMemory = 0;
	}
	
	protected void printStats() {
		System.out.println("Nodes explored during last search:  " + nodesExplored);
		System.out.println("Maximum memory usage during last search " + maxMemory);
	}
	
	protected void updateMemory(int currentMemory) {
		maxMemory = Math.max(currentMemory, maxMemory);
	}
	
	protected void incrementNodeCount() {
		nodesExplored++;
	}
	
	// a helper function to reverse the path
	// Adapted from: 
	// http://stackoverflow.com/questions/10766492/what-is-the-simplest-way-to-reverse-an-arraylist
	private ArrayList<UUSearchNode> reverse(ArrayList<UUSearchNode> list) {
	    for(int i = 0, j = list.size() - 1; i < j; i++) {
	        list.add(i, list.remove(j));
	    }
	    return list;
	}

}
