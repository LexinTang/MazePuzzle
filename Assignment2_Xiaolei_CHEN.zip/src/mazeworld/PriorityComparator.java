package mazeworld;

import java.util.Comparator;

public class PriorityComparator implements Comparator<UUSearchProblem.UUSearchNode> {
	@Override
	public int compare(UUSearchProblem.UUSearchNode x, UUSearchProblem.UUSearchNode y) {
		// Priority: smaller cost = higher priority
		
		return x.getValue() - y.getValue();
		
	}
}
