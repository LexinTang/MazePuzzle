


import heapq as HEAP
from collections import deque
from mazeworld_structures import *

# Heuristic is optimistic and assumes no walls from here to goal

def getPriority(cur_node, cur_priority, goal_position):
	return (cur_priority + heuristicValue(cur_node,goal_position))

def getPriorityMultibot( cur_node, cur_priority, goal_position):
	return (cur_priority + 5*heuristicValueMultibot(cur_node,goal_position))

def heuristicValue(cur_node,goal_position):
	return (abs(goal_position.row-cur_node.row) + abs(goal_position.col-cur_node.col) )

def heuristicValueMultibot(cur_node,goal_position):

	heuristic_cost = 0
	for a_robot in range(0,cur_node.num_robots):
		# Compute L1 distance between each robot and the goal
		temp_robot = cur_node.coordinates[a_robot]
		cur_goal = goal_position.coordinates[a_robot]

		heuristic_cost = heuristic_cost + heuristicValue(temp_robot,cur_goal)

	return heuristic_cost

def UCS_mazeworld(robot_location, mazeworld_grid, dimensions_maze, goal_position):

	visited_set = dict()
	visited_set.update({robot_location:None})	
	
	frontier = []
	frontier_cost = dict()	

	#HEAP.heappush(frontier, (0, robot_location))
	frontier_cost.update({robot_location:0})

	cur_children = getNeighbors(robot_location, mazeworld_grid, dimensions_maze, )

	for a_child in cur_children:
		HEAP.heappush(frontier, (1,a_child))
		frontier_cost.update({a_child:1})
		visited_set.update({a_child:robot_location})

	# Now begins the uniform cost search
	while len(frontier) > 0:

		(cur_priority,cur_node) = HEAP.heappop(frontier)
		

		if cur_node == goal_position:
			return backchain(cur_node, visited_set)

		# This allows for not visiting a higher cost node later on again
		coming_from = visited_set.values()

		if (cur_node not in coming_from):

			cur_children = getNeighbors(cur_node, mazeworld_grid,dimensions_maze)


			for a_child in cur_children:
				# If child is in visited set, check if priority for reaching child is lower from cur_node
				if a_child in visited_set:
					if frontier_cost[a_child] > (cur_priority+1):
						frontier_cost.update({a_child:(cur_priority+1)})
						visited_set.update({a_child:cur_node})
					
				else:
					HEAP.heappush(frontier, (cur_priority+1,a_child))
					visited_set.update({a_child:cur_node})
					frontier_cost.update({a_child:cur_priority+1})


def AStarSearch_mazeworld(robot_location, mazeworld_grid, dimensions_maze, goal_position, axis_handle):

	visited_set = dict()
	visited_set.update({robot_location:None})	

	frontier = []
	frontier_cost = dict()	

	#HEAP.heappush(frontier, (0, robot_location))
	root_priority = getPriority(robot_location, 0, goal_position)
	frontier_cost.update({robot_location:0})

	cur_children = getNeighbors(robot_location, mazeworld_grid, dimensions_maze, )

	for a_child in cur_children:
		estimate_priority = getPriority(a_child, frontier_cost[robot_location]+1, goal_position)
		HEAP.heappush(frontier, (estimate_priority,a_child))
		frontier_cost.update({a_child:frontier_cost[robot_location]+1})
		visited_set.update({a_child:robot_location})

	# Now begins the uniform cost search
	while len(frontier) > 0:

		#print frontier

		(cur_priority,cur_node) = HEAP.heappop(frontier)		
		if cur_node == goal_position:
			return backchain(cur_node, visited_set)

		# This allows for not visiting a higher cost node later on again
		coming_from = visited_set.values()
		# Condition below makes sure we don't revisit nodes we have already visited
		if (cur_node not in coming_from):
			#visualize_mazeworld(mazeworld_grid, dimensions_maze, axis_handle, cur_node, goal_position)
			cur_children = getNeighbors(cur_node, mazeworld_grid,dimensions_maze)

			for a_child in cur_children:
				# If child is in visited set, check if priority for reaching child is lower from cur_node

				if a_child in visited_set:

					# Compute heuristic at child					
					cur_path_cost = frontier_cost[cur_node]+1
					if frontier_cost[a_child] > cur_path_cost:
						frontier_cost.update({a_child:cur_path_cost})
						visited_set.update({a_child:cur_node})
					
				else:
					estimate_priority = getPriority(a_child, frontier_cost[cur_node]+1, goal_position)				
					HEAP.heappush(frontier, (estimate_priority,a_child))

					visited_set.update({a_child:cur_node})
					frontier_cost.update({a_child:frontier_cost[cur_node]+1})



def AStarSearch_mazeworld_multibot(robot_location, mazeworld_grid, dimensions_maze, goal_position, axis_handle):

	update_cost = 1

	visited_set = dict()
	visited_set.update({robot_location:None})	

	frontier = []
	frontier_cost = dict()	

	root_priority = getPriorityMultibot(robot_location, 0, goal_position)

	frontier_cost.update({robot_location:0})
	cur_children = getNeighborsMultibot(robot_location, mazeworld_grid, dimensions_maze )

	for a_child in cur_children:
		estimate_priority = getPriorityMultibot(a_child, frontier_cost[robot_location]+update_cost, goal_position)
		HEAP.heappush(frontier, (estimate_priority,a_child))
		frontier_cost.update({a_child:frontier_cost[robot_location]+update_cost})
		if (a_child == robot_location) == False:
			visited_set.update({a_child:robot_location})
		
	time = 0
	while len(frontier) > 0:

		(cur_priority,cur_node) = HEAP.heappop(frontier)		
		#print "Popped node: " + str(cur_node)
		if cur_node == goal_position:
			print "ENTERING BACKCHAIN"
			#return None
			return backchain(cur_node, visited_set)

#		# This allows for not visiting a higher cost node later on again
		coming_from = visited_set.values()
#		# Condition below makes sure we don't revisit nodes we have already visited
		#print "Looking at node: " + str(cur_node) 
		#print "Coming from set " + str(coming_from)
#		#print visited_set
		if (cur_node in coming_from) == False:

			#visualize_mazeworld_multibot(mazeworld_grid, dimensions_maze, axis_handle, cur_node, goal_position)
			
			cur_children = getNeighborsMultibot(cur_node, mazeworld_grid,dimensions_maze)
			#print "ALL CHILDREN :" + str(cur_children) + " of Node : " + str(cur_node)

			for a_child in cur_children:
				# If child is in visited set, check if priority for reaching child is lower from cur_node
				#print "Child is : " + str(a_child)
				#print "GOING TO LOOK HERE : " + str(visited_set)

				if (a_child in visited_set) == True:
					#print "Found child"
					# Compute heuristic at child					
					cur_path_cost = frontier_cost[cur_node]+update_cost
					if frontier_cost[a_child] > cur_path_cost:
						frontier_cost.update({a_child:cur_path_cost})
						visited_set.update({a_child:cur_node})
				else:
					# print "CHILD not found"
					estimate_priority = getPriorityMultibot(a_child, frontier_cost[cur_node]+update_cost, goal_position)				
					HEAP.heappush(frontier, (estimate_priority,a_child))
					visited_set.update({a_child:cur_node})
					frontier_cost.update({a_child:frontier_cost[cur_node]+update_cost})
					if (a_child == cur_node) == False:
						visited_set.update({a_child:cur_node})

		print "At time : "+ str(time)
		time = time+1

def BFS_mazeworld(robot_location, mazeworld_grid, dimensions_maze, goal_position):

	# Fast access of visited elements here	
	visited_set = dict()	
	visited_set.update({robot_location:None})

	list_of_choices = getNeighbors(robot_location, mazeworld_grid, dimensions_maze)	

	# Acknowledge that the first set of children came from the start state
	for a_child in list_of_choices:
		visited_set.update({a_child:robot_location})

	while len( list_of_choices ) > 0:

		# FIFO access order		
		a_node = list_of_choices.popleft()

		if ( a_node == goal_position ):
			return backchain(a_node, visited_set)

		else:
			# Find places you can go to from current node
			a_node_neighbors = getNeighbors(a_node, mazeworld_grid, dimensions_maze)						

			# We get none if there is no path that goes from here anywhere
			if len(a_node_neighbors) > 0:
				
				coming_from = visited_set.values()

				# Add all these children to the visited set.
				for a_child in a_node_neighbors:
					
					if (a_child in coming_from) == False:
						list_of_choices.append(a_child)	
						visited_set.update({a_child:a_node})


	# We implement this function
	# This returns a list of connected nodes
	# The basic idea is to use a hashmap to determine where we got to this node from
def backchain( cur_node, visited_set):

		# Create a queue
	#print "Entered backchain"
	path_to_goal = deque()
	path_to_goal.append(cur_node)	# This is the success state
	parent_node = visited_set[cur_node]
	#print path_to_goal
	while parent_node!=None:
		path_to_goal.appendleft(parent_node)
		parent_node = visited_set[parent_node]
	return path_to_goal
