# HARIS : I used this 
# 1- http://stackoverflow.com/questions/28429031/plotting-a-grid-with-matplotlib to help me understand how to plot stuff using matplotlib
# and
# 2- http://matthiaseisen.com/pp/patterns/p0203/
# to understand how to draw a rectangle

import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle,Ellipse
from mazeworld_structures import *
from search_methods import *

# How do we define the state space of mazeworld
# 1- array () with codes at location
# 2- hashmap () with keys being locations and values being what is present there (this is potentially better)

#####----------------------MAIN ROUTINE STARTS HERE-------------------------######

maze_file_name = "./sample_maze.txt"

dimensions_maze = get_line_count(maze_file_name)
maze_world_grid = read_mazeworld(maze_file_name, dimensions_maze)

my_mazeworld_vis = plt.figure()
axis_handle = my_mazeworld_vis.add_subplot(111,aspect='equal')
axis_handle.axis('off')
#plt.ion()
#plt.show()

robot_position = Coordinate(6,0)
goal_position = Coordinate(6,6)

#visualize_mazeworld(maze_world_grid, dimensions_maze, axis_handle, robot_position, goal_position)
print "BFS"
path_to_goal_BFS = BFS_mazeworld(robot_position, maze_world_grid, dimensions_maze, goal_position)
print "Finshed BFS"
print "---------------"
print "UCS"
path_to_goal_UCS = UCS_mazeworld(robot_position, maze_world_grid, dimensions_maze, goal_position)
print "Finshed UCS"
print "---------------"


print "A* Search"
path_to_goal_AStartSearch = AStarSearch_mazeworld(robot_position, maze_world_grid, dimensions_maze, goal_position, axis_handle)
print "Finshed A* Search"
print "---------------"

#alize_motion(path_to_goal_AStartSearch, maze_world_grid, dimensions_maze, goal_position, axis_handle)
#visualize_mazeworld(maze_world_grid, dimensions_maze, axis_handle, path_to_goal_AStartSearch[0], goal_position)
#plt.show()

print "Multi Robot"
print "-----------------------------"


#bot_locations_start = MultiCoordinate([6,0,0,1,1,4,0])
# k turns later everything is good as same state is allowed
#bot_locations_goal =  MultiCoordinate([5,6,4,6,6,6,0]) 

maze_file_name = "./sample_maze.txt"
dimensions_maze = get_line_count(maze_file_name)
maze_world_grid = read_mazeworld(maze_file_name, dimensions_maze)
bot_locations_start = MultiCoordinate([6,0,0])
bot_locations_goal = MultiCoordinate([6,6,0])

print "A*-MULTIBOT with 1 Robot"
path_to_goal_AStar1 = AStarSearch_mazeworld_multibot(bot_locations_start, maze_world_grid, dimensions_maze, bot_locations_goal, axis_handle)
print "Finshed MultiBot A*"
print "---------------"

#visualize_motion_multibot(path_to_goal_AStar1, maze_world_grid, dimensions_maze, bot_locations_goal, axis_handle)



maze_file_name = "./multirobot_maze.txt"
dimensions_maze = get_line_count(maze_file_name)
maze_world_grid = read_mazeworld(maze_file_name, dimensions_maze)
bot_locations_start = MultiCoordinate([6,0,1,4,0])
bot_locations_goal =  MultiCoordinate([6,6,5,6,0]) 

print "A*-MULTIBOT with 2 Robots"
path_to_goal_AStar2 = AStarSearch_mazeworld_multibot(bot_locations_start, maze_world_grid, dimensions_maze, bot_locations_goal, axis_handle)
print "Finshed MultiBot A*"
print "---------------"
#visualize_motion_multibot(path_to_goal_AStar2, maze_world_grid, dimensions_maze, bot_locations_goal, axis_handle)


maze_file_name = "./multirobot_maze.txt"
dimensions_maze = get_line_count(maze_file_name)
maze_world_grid = read_mazeworld(maze_file_name, dimensions_maze)
bot_locations_start = MultiCoordinate([6,0,0,1,1,4,0])
bot_locations_goal =  MultiCoordinate([5,6,4,6,6,6,0]) 

print "A*-MULTIBOT with 3 Robots"
path_to_goal_AStar3 = AStarSearch_mazeworld_multibot(bot_locations_start, maze_world_grid, dimensions_maze, bot_locations_goal, axis_handle)
print "Finshed MultiBot A*"
print "---------------"
#visualize_motion_multibot(path_to_goal_AStar3, maze_world_grid, dimensions_maze, bot_locations_goal, axis_handle)


maze_file_name = "./mazeworld_corridor.txt"
dimensions_maze = get_line_count(maze_file_name)
maze_world_grid = read_mazeworld(maze_file_name, dimensions_maze)
bot_locations_start = MultiCoordinate([10,5,9,5,1,5,0])
bot_locations_goal =  MultiCoordinate([3,5,7,5,8,5,0]) 

print "A*-MULTIBOT with 3 Robots"
path_to_goal_AStar3 = AStarSearch_mazeworld_multibot(bot_locations_start, maze_world_grid, dimensions_maze, bot_locations_goal, axis_handle)
print "Finshed MultiBot A*"
print "---------------"
#visualize_motion_multibot(path_to_goal_AStar3, maze_world_grid, dimensions_maze, bot_locations_goal, axis_handle)

maze_file_name = "./maze_20.txt"
dimensions_maze = get_line_count(maze_file_name)
maze_world_grid = read_mazeworld(maze_file_name, dimensions_maze)
bot_locations_start = MultiCoordinate([3,5,4,5,5,5,0])
bot_locations_goal =  MultiCoordinate([17,4,17,5,17,6,0]) 

print "A*-MULTIBOT with 3 Robots"
path_to_goal_AStar3 = AStarSearch_mazeworld_multibot(bot_locations_start, maze_world_grid, dimensions_maze, bot_locations_goal, axis_handle)
print "Finshed MultiBot A*"
print "---------------"
#visualize_motion_multibot(path_to_goal_AStar3, maze_world_grid, dimensions_maze, bot_locations_goal, axis_handle)


maze_file_name = "./tight_maze.txt"
dimensions_maze = get_line_count(maze_file_name)
maze_world_grid = read_mazeworld(maze_file_name, dimensions_maze)
bot_locations_start = MultiCoordinate([2,0,1,0,0,0,0])
bot_locations_goal =  MultiCoordinate([4,4,4,5,4,6,0]) 

print "A*-MULTIBOT with 3 Robots"
path_to_goal_AStar3 = AStarSearch_mazeworld_multibot(bot_locations_start, maze_world_grid, dimensions_maze, bot_locations_goal, axis_handle)
print "Finshed MultiBot A*"
print "---------------"
visualize_motion_multibot(path_to_goal_AStar3, maze_world_grid, dimensions_maze, bot_locations_goal, axis_handle)



