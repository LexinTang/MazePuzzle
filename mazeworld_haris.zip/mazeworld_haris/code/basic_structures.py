# Allowing for max maze dimension of 99 before hash collides
class Coordinate:

	def __init__(self, row, col):
		self.row = row
		self.col = col

	def __ne__(self,other):		
		return not self.__eq__(other)

	def __eq__(self, other):
		if isinstance(other,Coordinate):
			#print "Comparing R2R " + str(self.row)  +"v"+str(other.row)
			#print "Comparing C2C " + str(self.col)  +"v"+str(other.col)
			return ( ( self.row == other.row) and (self.col==other.col) )
		else:
			#print "Returning false because NOT COORDINATE"
			return False

	def __hash__(self):
		return self.row*1000 + self.col*100

	def __str__(self):
		return "("+str(self.row)+", "+str(self.col) + ")"

	def __repr__(self):
		return self.__str__()
