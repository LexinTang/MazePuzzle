# Looked http://stackoverflow.com/questions/1500718/what-is-the-right-way-to-override-the-copy-deepcopy-operations-on-an-object-in-p to determine how to do deepcopy


import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle,Ellipse
from collections import deque
from basic_structures import *

class MultiCoordinate:

	def __init__(self, locations):
		self.coordinates = dict()	
		last_element = (len(locations)-1)
		self.num_robots = last_element/2
		self.turn_index = locations[last_element]	# First robots turn

		for a_robot in range(0,self.num_robots):
			self.coordinates.update({a_robot:Coordinate(locations[a_robot*2],locations[a_robot*2+1])})

		# Finished adding all robots

	def __eq__(self, other):
		decision = True
		
		if isinstance(other,MultiCoordinate) == False:
			#print "returning false as object is none"
			return False		

		# Check if any robot has different coordinates
		for a_robot in range(0,self.num_robots):
			#print "Comparing : " + str(self.coordinates[a_robot]) + " with " + str(other.coordinates[a_robot])
			if self.coordinates[a_robot] != other.coordinates[a_robot]:
				decision = False
				#print "Found Diff Coord"
				break


		# Check if its the same robots turn
		if (decision == True):
			if self.turn_index != other.turn_index :
				#print "Turn is not the same"
				decision = False
			else:
				#print "Turn is the same"
				decision = True

		#print "EQ called for " + self.__str__() + " vs " + other.__str__() + "and decision is :" + str(decision)
		return decision

	def __hash__(self):
		base = 10000
		cur_base = 1
		cur_hash = 0
		for a_robot in range(0,self.num_robots):			
			cur_base = cur_base*base
			cur_hash = cur_hash + (cur_base*self.coordinates[a_robot].__hash__())

		cur_base = cur_base*base
		cur_hash = cur_hash + cur_base*self.turn_index
		#print "HASH CALLED for " + self.__str__() + " to return " + str(cur_hash)
		return cur_hash


	def __str__(self):
		str_rep = "[ "

		for a_bot in range(0,self.num_robots):
			str_rep = str_rep + str(self.coordinates[a_bot]) + " "
		str_rep = str_rep + ", T: " + str(self.turn_index) + "]"


		return str_rep

	def __repr__(self):
		return self.__str__()


def deepcopy(cur_node):

	locations = []
	for a_robot in range(0,cur_node.num_robots):
		cur_coord = cur_node.coordinates[a_robot]
		locations.append( cur_coord.row )
		locations.append( cur_coord.col )

	locations.append(cur_node.turn_index)	
	new_list = MultiCoordinate(locations)

	return new_list

# Only up-down left right are valid
# Check if the move is in the maze and is not occupied
def getNeighbors(a_node, mazeworld_grid, dimensions_maze):

	allowed_moves = deque()

	up_node = Coordinate(a_node.row-1, a_node.col)
	down_node = Coordinate(a_node.row+1, a_node.col)
	left_node = Coordinate(a_node.row,a_node.col-1)
	right_node = Coordinate(a_node.row,a_node.col+1)

	if (a_node.row-1) >= 0:
		if (mazeworld_grid[up_node] == 1) :
			allowed_moves.append(up_node)

	if (a_node.row+1) < dimensions_maze[0]:
		if (mazeworld_grid[down_node] == 1) :
			allowed_moves.append(down_node)

	if (a_node.col-1) >= 0:
		if (mazeworld_grid[left_node] == 1) :
			allowed_moves.append(left_node)		

	if (a_node.col+1) < dimensions_maze[1]:
		if ( mazeworld_grid[right_node] == 1) :
			allowed_moves.append(right_node)		

	return allowed_moves

def getNeighborsMultibot(robot_location, mazeworld_grid, dimensions_maze ):

	# Pick whose turn it is
	allowed_moves = deque()

	# Finding out whose turn is it
	cur_bot = robot_location.turn_index

	# Updating the turn for the next player
	robot_location.turn_index = robot_location.turn_index+1
	if robot_location.turn_index == robot_location.num_robots:
		robot_location.turn_index = 0	# Return turn to 1st player

	#same_node_loc = deepcopy(robot_location)	
	#allowed_moves.append(same_node_loc)
	
	same_location = deepcopy(robot_location)
	allowed_moves.append(same_location)

	a_node = robot_location.coordinates[cur_bot]	

	up_node = Coordinate(a_node.row-1, a_node.col)
	down_node = Coordinate(a_node.row+1, a_node.col)
	left_node = Coordinate(a_node.row,a_node.col-1)
	right_node = Coordinate(a_node.row,a_node.col+1)

	# ALSO CHECK FOR COLLISIONS
	all_robots_loc = robot_location.coordinates.values()

	if (a_node.row-1) >= 0:
		if (mazeworld_grid[up_node] == 1) and (up_node not in all_robots_loc):
			up_node_update = deepcopy(robot_location)
			up_node_update.coordinates.update({cur_bot:up_node})
			allowed_moves.append(up_node_update)

	if (a_node.row+1) < dimensions_maze[0]:
		if (mazeworld_grid[down_node] == 1) and (down_node not in all_robots_loc):
			down_node_update = deepcopy(robot_location)
			down_node_update.coordinates.update({cur_bot:down_node})			
			allowed_moves.append(down_node_update)

	if (a_node.col-1) >= 0:
		if (mazeworld_grid[left_node] == 1) and (left_node not in all_robots_loc):
			left_node_update = deepcopy(robot_location)
			left_node_update.coordinates.update({cur_bot:left_node})			
			allowed_moves.append(left_node_update)		

	if (a_node.col+1) < dimensions_maze[1]:
		if ( mazeworld_grid[right_node] == 1) and (right_node not in all_robots_loc):
			right_node_update = deepcopy(robot_location)
			right_node_update.coordinates.update({cur_bot:right_node})			
			allowed_moves.append(right_node_update)		

	# Return original robot's turn index
	if (robot_location.turn_index == 0):
		robot_location.turn_index = robot_location.num_robots-1
	else:
		robot_location.turn_index = robot_location.turn_index-1 

	return allowed_moves

# Functions below correspond to IO and visualization routines

def get_line_count(file_path):
	# Strip function removes the \n character from lines read
	DATA_FILE = open(file_path,'r')

	cur_counter = 1;
	a_line = DATA_FILE.readline().strip()

	width_maze = len(a_line)
	while (len(a_line) > 0):
		a_line = DATA_FILE.readline().strip()
		if len(a_line) == width_maze:
			cur_counter = cur_counter + 1

	return (cur_counter, width_maze)

# Write a read maze function
def read_mazeworld(file_path, dimensions_maze):

	maze_width = dimensions_maze[0]
	maze_height = dimensions_maze[1]

	maze_world_grid = dict()

	DATA_FILE = open(file_path,'r')

	for a_row in range(0, maze_width):

		a_line = DATA_FILE.readline()

		for a_col in range(0,maze_height):
			a_grid_cell = Coordinate(a_row,a_col)
			if a_line[a_col] is ".":
				maze_world_grid.update({a_grid_cell:1})
			elif a_line[a_col] is "#":
				maze_world_grid.update({a_grid_cell:0})
#			elif a_line[a_col] is "A":
#				maze_world_grid.update({a_grid_cell:2})
#			elif a_line[a_col] is "B":
#				maze_world_grid.update({a_grid_cell:3})				
#			elif a_line[a_col] is "C":
#				maze_world_grid.update({a_grid_cell:4})				

	return maze_world_grid
	# Now we know what 

# Write a visualize mazeworld function:
def visualize_mazeworld_multibot(maze_world_grid, dimensions_maze, axis_handle, robot_position, goal_position):
	
	# Some constants defined on how to draw the maze
	# 1- Each block has a size of 0.1 units

	colors = ["#C0392B","#2980B9","#F1C40F"]


	goals = ["#641E16","#154360","#7D6608"] 


	cell_width = 0.05
	cell_height = 0.05

	for a_row in range(0, dimensions_maze[0]):
		for a_col in range(0, dimensions_maze[1]):

			coord_loc = ( a_col*cell_width, 0.6 - a_row*cell_height + cell_height)
			#print coord_loc

			grid_value = maze_world_grid[Coordinate(a_row,a_col)]
			
			if grid_value == 1:
				axis_handle.add_patch( Rectangle( coord_loc, cell_width, cell_height, fill=True, facecolor="#F17154", alpha=1 ) )
			else:
				axis_handle.add_patch( Rectangle( coord_loc, cell_width, cell_height, fill=True, facecolor="#89807E", alpha=1, hatch='x' ) )

	for a_robot in range(0, robot_position.num_robots):
		cur_robot_position = robot_position.coordinates[a_robot]
		robot_coord = ( cur_robot_position.col*cell_width + cell_height*.5, 0.6 - cur_robot_position.row*cell_height + cell_height*1.5)
		axis_handle.add_patch( Ellipse( robot_coord, cell_width*0.8, cell_height*0.8, fill=True, facecolor=colors[a_robot], alpha=1 ) )	

		cur_goal_position = goal_position.coordinates[a_robot]
		goal_coord = ( cur_goal_position.col*cell_width + cell_height*.5, 0.6 - cur_goal_position.row*cell_height + cell_height*1.5)
		axis_handle.add_patch( Ellipse( goal_coord, cell_width*0.8, cell_height*0.8, fill=True, facecolor=goals[a_robot], alpha=0.5 ) )	

	
	plt.draw()
	plt.pause(0.1)



# Write a visualize mazeworld function:
def visualize_mazeworld(maze_world_grid, dimensions_maze, axis_handle, robot_position, goal_position):
	
	# Some constants defined on how to draw the maze
	# 1- Each block has a size of 0.1 units

	cell_width = 0.1
	cell_height = 0.1

	for a_row in range(0, dimensions_maze[0]):
		for a_col in range(0, dimensions_maze[1]):

			coord_loc = ( a_col*cell_width, 0.6 - a_row*cell_height + cell_height)
			#print coord_loc

			grid_value = maze_world_grid[Coordinate(a_row,a_col)]
			
			if grid_value == 1:
				axis_handle.add_patch( Rectangle( coord_loc, cell_width, cell_height, fill=True, facecolor="#F17154", alpha=1 ) )
			else:
				axis_handle.add_patch( Rectangle( coord_loc, cell_width, cell_height, fill=True, facecolor="#89807E", alpha=1, hatch='x' ) )


	goal_coord = ( goal_position.col*cell_width + cell_height*.5, 0.6 - goal_position.row*cell_height + cell_height*1.5)
	axis_handle.add_patch( Ellipse( goal_coord, cell_width*0.8, cell_height*0.8, fill=True, facecolor="#871321", alpha=0.5 ) )	

	robot_coord = ( robot_position.col*cell_width + cell_height*.5, 0.6 - robot_position.row*cell_height + cell_height*1.5)
	axis_handle.add_patch( Ellipse( robot_coord, cell_width*0.8, cell_height*0.8, fill=True, facecolor="#088163", alpha=1 ) )	

	plt.draw()
	plt.pause(1)

def visualize_motion(path_to_goal, maze_world_grid, dimensions_maze, goal_position, axis_handle):

	a_step = 0
	for cur_robot_position in path_to_goal:
		print "Step: " + str(a_step)
		visualize_mazeworld(maze_world_grid, dimensions_maze, axis_handle, cur_robot_position, goal_position)	
		a_step = a_step+1


def visualize_motion_multibot(path_to_goal, maze_world_grid, dimensions_maze, goal_position, axis_handle):

	a_step = 0
	for cur_robot_position in path_to_goal:
		print "Step: " + str(a_step)
		visualize_mazeworld_multibot(maze_world_grid, dimensions_maze, axis_handle, cur_robot_position, goal_position)	
		a_step = a_step+1
